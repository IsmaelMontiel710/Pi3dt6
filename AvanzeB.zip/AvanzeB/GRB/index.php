<?php
$con = mysqli_connect("localhost", "root", "", "sales");
if (!$con) {
    echo "Error al conectarse a la base de datos" . mysqli_error();
} else {
    $sql = "SELECT * FROM tblsales";
    $result = mysqli_query($con, $sql);
    $chart_data = "";

    $productname = array();
    $sales = array();
    while ($row = mysqli_fetch_array($result)) {
        $productname[] = $row['product'];
        $sales[] = $row['totaldeproductos'];
    }
}

// Definir un arreglo de colores que se repetirán para cada producto
$colors = array(
    "#FF7F50",
    "#5945fd",
    "#25d5f2",
    "#FA3107",
    // Añadir más colores según sea necesario
);
?>

<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title>SISTEMA DE INVENTARIO</title>
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <style>
        /* Estilo para el contenedor del título con caja morada */
        .purple-box {
            background-color: purple;
            padding: 10px;
            border-radius: 5px;
            text-align: center;
        }

        /* Estilo para el texto del título */
        .chart-title {
            color: white;
            font-size: 24px;
            margin: 0; /* Elimina el margen predeterminado */
        }

        /* Estilo para el contenedor del gráfico */
        .chart-container {
            position: relative;
            margin-top: 20px;
            width: 100%;
            height: auto; /* Esto permite que el canvas se adapte al contenedor */
        }
    </style>
</head>

<body>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header bg">
                        <div class="purple-box">
                            <h1 class="chart-title">SISTEMA DE INVENTARIO</h1>
                        </div>
                    </div>
                    <div class="card-body">
                        <div class="chart-container">
                            <canvas id="chartjs_bar"></canvas>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/Chart.js/2.4.0/Chart.min.js"></script>
    <script type="text/javascript">
        var ctx = document.getElementById("chartjs_bar").getContext('2d');
        var myChart = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: <?php echo json_encode($productname); ?>,
                datasets: [{
                    backgroundColor: <?php
                    $colorCount = count($colors);
                    $colorIndexes = array_keys($productname);
                    $colorIndexes = array_map(function ($index) use ($colorCount) {
                        return $index % $colorCount;
                    }, $colorIndexes);
                    echo json_encode(array_map(function ($colorIndex) use ($colors) {
                        return $colors[$colorIndex];
                    }, $colorIndexes));
                    ?>,
                    data: <?php echo json_encode($sales); ?>
                }]
            },
            options: {
                legend: {
                    display: false,
                },
                responsive: true, // Hacer el gráfico responsivo
                maintainAspectRatio: false, // Permite que el canvas se ajuste al contenedor
            }
        });
    </script>
</body>

</html>

