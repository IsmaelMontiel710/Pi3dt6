(function () {

    const btnEliminacion = document.querySelectorAll(".btnEliminacion");

    btnEliminacion.forEach(btn => {
        btn.addEventListener('click', (e) => {
            const confirmacion = confirm('¿Seguro de eliminar el curso?');
            if (!confirmacion) {
                e.preventDefault();
            }
        });
    });
    
})();

// auto-dismiss.js
document.addEventListener("DOMContentLoaded", function() {
    var autoDismissAlerts = document.querySelectorAll('[data-bs-auto-dismiss]');
    
    autoDismissAlerts.forEach(function(alert) {
        var timeout = parseInt(alert.getAttribute('data-bs-auto-dismiss'));
        
        if (!isNaN(timeout)) {
            setTimeout(function() {
                var bsAlert = new bootstrap.Alert(alert);
                bsAlert.close();
            }, timeout);
        }
    });
});

document.getElementById('NumPrecio').addEventListener('input', function() {
    let value = this.value.trim();
    if (value.length > 7) {
        value = value.substring(0, 7);
        this.value = value;
    }
});

