from django.urls import path
from . import views

urlpatterns = [

    path('', views.home),
    path('registrarProducto/', views.registrarProducto),
    path('edicioninventario/<idproducts>', views.edicioninventario),
    path('editarProducto/', views.editarProducto),
    path('eliminainventario/<idproducts>', views.eliminaInventario),
    path('get_char/', views.get_char),
    
    
]
