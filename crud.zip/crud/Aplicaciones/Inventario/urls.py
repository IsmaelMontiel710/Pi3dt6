from django.urls import path
from . import views

urlpatterns = [

    path('', views.home),
    path('registrarProducto/', views.registrarProducto),
    path('edicioninventario/<codigo>', views.edicioninventario),
    path('editarProducto/', views.editarProducto),
    path('eliminainventario/<codigo>', views.eliminaInventario),
    #path('get_chart/', views.get_chart, name = 'get_chart')
    
]
