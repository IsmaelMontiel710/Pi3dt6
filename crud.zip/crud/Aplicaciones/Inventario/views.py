
from django.shortcuts import render, redirect
from .models import Productos
from django.contrib import messages
from django.http.response import JsonResponse

def home(request):
    ProductosListados = Productos.objects.all()
    messages.success(request, '¡Productos Listados!')
    return render(request, 'inventario.html', {"Productos": ProductosListados} )

def registrarProducto(request):
    codigo = request.POST['txtCodigo']
    nombre = request.POST['txtNombre']
    precio = request.POST['NumPrecio']
    marca = request.POST['NomMarca']
    cantPro = request.POST['CantPro'] 

    productos = Productos.objects.create( codigo=codigo, nombre=nombre, precio=precio, marca= marca, cantPro=cantPro)
    messages.success(request, '¡Producto registrado!')
    return redirect('/')

def edicioninventario(request, idproducts):
    productos = Productos.objects.get(idproducts= idproducts)
    return render(request, "edicioninventario.html", {"productos": productos})

def editarProducto(request):
    idproducts = request.POST.get('idproducts')
    codigo = request.POST.get('txtCodigo')
    nombre = request.POST.get('txtNombre')
    precio = request.POST.get('NumPrecio')
    marca = request.POST.get('NomMarca')
    cantPro = request.POST.get('CantPro')

    productos = Productos.objects.get(idproducts=idproducts)
    productos.codigo = codigo
    productos.nombre = nombre
    productos.precio = precio
    productos.marca = marca
    productos.cantPro = cantPro
    productos.save()

    messages.success(request, '¡Producto Editado!')
    return redirect('/')




def eliminaInventario(request, idproducts):
    productos = Productos.objects.get(idproducts=idproducts)
    productos.delete()
    messages.success(request, '¡Producto Eliminado!')
    return redirect('/')

def grafica(request):
    return render(request, '/')

def get_char(_request):
    chart = {}
    return JsonResponse(chart)