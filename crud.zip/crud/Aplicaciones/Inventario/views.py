
from django.shortcuts import render, redirect
from .models import Productos
from django.contrib import messages
from django.http.response import JsonResponse

def home(request):
    ProductosListados = Productos.objects.all()
    messages.success(request, '¡Productos Listados!')
    return render(request, 'inventario.html', {"Productos": ProductosListados} )

def registrarProducto(request):
    codigo = request.POST['txtCodigo']
    nombre = request.POST['txtNombre']
    creditos = request.POST['NumPrecio']

    productos = Productos.objects.create( codigo=codigo, nombre=nombre, creditos=creditos)
    messages.success(request, '¡Producto registrado!')
    return redirect('/')

def edicioninventario(request, codigo):
    productos = Productos.objects.get(codigo=codigo)
    return render(request, "edicioninventario.html", {"productos": productos})

def editarProducto(request):
    codigo = request.POST.get('txtCodigo')
    nombre = request.POST.get('txtNombre')
    creditos = request.POST.get('NumPrecio')

    productos = Productos.objects.get(codigo=codigo)
    productos.nombre = nombre
    productos.creditos = creditos
    productos.save()
    messages.success(request, '¡Producto Editado!')
    return redirect('/')

def eliminaInventario(request, codigo):
    productos = Productos.objects.get(codigo=codigo)
    productos.delete()
    messages.success(request, '¡Producto Eliminado!')
    return redirect('/')

def grafica(request):
    return render(request, '/')

def get_char(request):
    chart = {}
    return JsonResponse(chart)