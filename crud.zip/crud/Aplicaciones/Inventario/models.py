from django.db import models


class Productos(models.Model):
    idproducts = models.AutoField(primary_key=True)
    codigo = models.CharField(max_length=255)
    nombre = models.CharField(max_length=50)
    precio = models.PositiveBigIntegerField()
    marca = models.CharField(max_length=255)
    cantPro = models.CharField(max_length=255)
    def __str__(self):
        texto = "{0} ({1})"
        return texto.format(self.nombre, self.creditos)
